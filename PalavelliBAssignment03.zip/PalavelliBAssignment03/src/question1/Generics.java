/**
 * 
 */
package question1;

/**
 * @author Bala Harinadh Palavelli
 *
 */
public class Generics<T> {
	private T value;
	/**
	 * @return the value
	 */
	public T getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(T value) {
		this.value = value;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Generics<Integer> intobj = new Generics<>();
		intobj.setValue(5);
		System.out.println("The Integer Value is: "+intobj.getValue());
		
		Generics<String> StringObj = new Generics<>();
		StringObj.setValue("Bala");
		System.out.println("The String Value is: "+StringObj.getValue());
	}

}
