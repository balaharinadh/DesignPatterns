package question2;

public class Circle extends Shape{
	// valid override because both methods are public
    public void draw() {
        System.out.println("Drawing a circle");
    }

    // valid override because the subclass is in the same package and protected is more accessible than default
    protected void erase() {
        System.out.println("Erasing a circle");
    }

    // invalid override because private is more restrictive than default
   // private void fill() {
       // System.out.println("Filling a circle");
    //}

}
