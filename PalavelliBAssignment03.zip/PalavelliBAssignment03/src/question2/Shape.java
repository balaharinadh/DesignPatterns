/**
 * 
 */
package question2;

/**
 * @author Bala Harinadh Palavelli
 *
 */
public class Shape  {
	public void draw() {
        System.out.println("Drawing a shape");
    }

    protected void fill() {
        System.out.println("Filling a shape");
    }

    void erase() {
        System.out.println("Erasing a shape");
    }
}
