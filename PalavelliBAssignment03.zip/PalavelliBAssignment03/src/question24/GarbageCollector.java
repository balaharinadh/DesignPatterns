package question24;

public class GarbageCollector {
	public static void main(String[] args) {
        // create an object that we will later make eligible for garbage collection
        Object o1 = new Object();
        
        // print memory information before requesting garbage collection
        System.out.println("Total memory: " + Runtime.getRuntime().totalMemory());
        System.out.println("Free memory before gc(): " + Runtime.getRuntime().freeMemory());
        
        // request garbage collection
        System.gc();
        
        // print memory information after requesting garbage collection
        System.out.println("Free memory after gc(): " + Runtime.getRuntime().freeMemory());
        
        // make the object eligible for garbage collection
        o1 = null;
    }

}
