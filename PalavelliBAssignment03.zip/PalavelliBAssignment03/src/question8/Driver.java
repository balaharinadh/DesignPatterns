package question8;

import java.io.FileWriter;
import java.io.IOException;

public class Driver {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileWriter obj=null;
		try {
		    obj = new FileWriter("output.txt");
		    obj.write("Hello, world!");
		    // Code that writes more data to the file
		} finally {
		    if (obj != null) {
		        try {
		            obj.close();
		        } catch (IOException e) {
		            // Handle the exception
		        }
		    }
		    System.out.println("Cleanup complete.");
		}

	}

}
