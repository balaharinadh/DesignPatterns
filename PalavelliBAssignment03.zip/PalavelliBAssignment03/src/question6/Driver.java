/**
 * 
 */
package question6;

/**
 * @author S549411
 *
 */
public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Hello";
		str += " ";
		str += "world";
		System.out.println(str); // Output: "Hello world"

		StringBuffer sb = new StringBuffer();
		sb.append("Hello");
		sb.append(" ");
		sb.append("world");
		System.out.println(sb.toString()); // Output: "Hello world"


	}

}
