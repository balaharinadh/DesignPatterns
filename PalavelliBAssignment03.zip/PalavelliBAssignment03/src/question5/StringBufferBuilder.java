/**
 * 
 */
package question5;

/**
 * @author S549411
 *
 */
public class StringBufferBuilder {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		sb.append("Bala");
		sb.append(" ");
		sb.append("Harinadh");
		System.out.println(sb.toString()); // Output: "Bala Harinadh"

		StringBuffer sbf = new StringBuffer();
		sbf.append("Bala");
		sbf.append(" ");
		sbf.append("Harinadh");
		System.out.println(sbf.toString()); // Output: "Bala Harinadh"


	}

}
