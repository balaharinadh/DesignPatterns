package question10;

import java.io.IOException;

public class Animal {
	public void makeSound() throws IOException {
        // superclass method throws IOException
    }

}
