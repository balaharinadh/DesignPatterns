package question10;

public class Dog {
	// Compiler error: overridden method does not throw IOException
    public void Breed() throws Exception {
        // subclass method throws Exception
    }

}
