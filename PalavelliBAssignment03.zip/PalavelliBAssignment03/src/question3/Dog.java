package question3;

public class Dog extends Animal {
	@Override
    public Dog getSelf() {
        return this;
    }

}
