/**
 * 
 */
package question3;

/**
 * @author S549411
 *
 */
public class Animal {
	public Animal getSelf() {
        return this;
    }

}
