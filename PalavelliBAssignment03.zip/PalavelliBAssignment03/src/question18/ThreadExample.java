/**
 * 
 */
package question18;

/**
 * @author S549411
 *
 */
public class ThreadExample extends Thread  {
	 public void run() {
	        System.out.println("Thread is running");
	    }

	    public static void main(String[] args) {
	        ThreadExample thread = new ThreadExample();
	        thread.start(); // start the thread

	        // Try to start the same thread again
	        try {
	            thread.start();
	        } catch (IllegalThreadStateException e) {
	            System.out.println("IllegalThreadStateException caught!");
	        }
	    }
}
