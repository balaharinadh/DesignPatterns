/**
 * 
 */
package question14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author S549411
 *
 */
public class SynchronousArrayList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> list = new ArrayList<>();
		synchronized(list) {
		    // Access and modify the ArrayList here
		    list.add("Java");
		    list.add("Python");
		}
		System.out.println(list);

		List<String> l2 = new ArrayList<>();
		List<String> synchronizedList = Collections.synchronizedList(l2);
		synchronized(synchronizedList) {
		    // Access and modify the synchronized ArrayList here
		    synchronizedList.add("Java");
		    synchronizedList.add("Python");
		}
		System.out.println(synchronizedList);
		
		List<String> l3 = new CopyOnWriteArrayList<>();
		l3.add("Java");
		l3.add("Python");
		// No need for synchronization, as all operations are thread-safe

         System.out.println(l3);


	}

}
