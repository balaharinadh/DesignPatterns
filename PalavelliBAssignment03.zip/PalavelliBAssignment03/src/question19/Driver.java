/**
 * 
 */
package question19;

/**
 * @author S549411
 *
 */
public class Driver implements Runnable {
	public void run() {
        System.out.println("Driver is running");
    }

    public static void main(String[] args) {
        Driver myRunnable = new Driver();
        Thread thread = new Thread(myRunnable);
        thread.start();
    }
}
