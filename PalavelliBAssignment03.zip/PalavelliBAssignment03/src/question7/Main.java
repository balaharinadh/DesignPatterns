/**
 * 
 */
package question7;

/**
 * @author S549411
 *
 */
public class Main {

	/**
	 * 
	 */
	final public Main() {
		
	}
}
