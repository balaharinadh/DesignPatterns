/**
 * 
 */
package question17;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author S549411
 *
 */
public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
	        
	        // Fail-fast iterator
	        Iterator<Integer> iterator = list.iterator();
	        while (iterator.hasNext()) {
	            Integer num = iterator.next();
	            if (num == 3) {
	                list.remove(num); // throws ConcurrentModificationException
	            }
	        }
	        
	        // Fail-safe iterator
	        iterator = new CopyOnWriteArrayList<>(list).iterator();
	        while (iterator.hasNext()) {
	            Integer num = iterator.next();
	            if (num == 3) {
	                list.remove(num); // doesn't throw ConcurrentModificationException
	            }
	        }

	}

}
