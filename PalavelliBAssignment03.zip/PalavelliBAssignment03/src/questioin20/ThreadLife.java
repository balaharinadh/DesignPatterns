/**
 * 
 */
package questioin20;

/**
 * @author S549411
 *
 */
public class ThreadLife {
	public static void main(String[] args) throws InterruptedException {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Thread is running in " + Thread.currentThread().getState() + " state.");
            }
        });
        System.out.println("Thread is created in " + thread.getState() + " state.");
        thread.start();
        System.out.println("Thread is started in " + thread.getState() + " state.");
        thread.sleep(1000);
        System.out.println("Thread is sleeping in " + thread.getState() + " state.");
        thread.join();
        System.out.println("Thread is joined in " + thread.getState() + " state.");
    }

}
