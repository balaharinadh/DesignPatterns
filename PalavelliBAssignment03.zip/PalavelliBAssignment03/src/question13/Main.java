/**
 * 
 */
package question13;

import java.util.ArrayList;
import java.util.Vector;

/**
 * @author S549411
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ArrayList<String> AList = new ArrayList<>();
        Vector<String> vector = new Vector<>();

        // Adding elements to ArrayList and Vector
        AList.add("Bala");
        AList.add("Hari");
        AList.add("Nadh");

        vector.add("Watches");
        vector.add("Wallet");
        vector.add("Bracelete");

        // Accessing an element from ArrayList and Vector
        System.out.println("Element at index 1 in ArrayList: " + AList.get(1));
        System.out.println("Element at index 1 in Vector: " + vector.get(1));

        // Removing an element from ArrayList and Vector
        AList.remove(2);
        vector.remove(2);

        // Traversing elements using Iterator in ArrayList and Vector
        System.out.println("Elements in ArrayList:");
        for (String names : AList) {
            System.out.println(names);
        }

        System.out.println("Elements in Vector:");
        for (String accessories : vector) {
            System.out.println(accessories);
        }

}
}


