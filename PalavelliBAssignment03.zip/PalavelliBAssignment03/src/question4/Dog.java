package question4;

public class Dog extends Animal {
	private static void Type() {
        System.out.println("Dog");
    }

    @Override
    public void Breed() {
       Type(); // calls the Dog.Type() method
        System.out.println("Poddle");

}
}
