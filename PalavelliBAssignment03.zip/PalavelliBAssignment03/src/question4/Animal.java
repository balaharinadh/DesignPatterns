package question4;

public class Animal {
	private static void Type() {
        System.out.println("Animal");
    }

    public void Breed() {
        Type(); // calls the Animal.Type() method
        System.out.println("Animal Breed");
    }

}
