package question4;

public class AnimalDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a1=new Dog();
		a1.Breed();

	}

}
