/**
 * 
 */
package question15;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

/**
 * @author S549411
 *
 */
public class Hash {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Creating a HashMap
        Map<Integer, String> hashMap = new HashMap<Integer, String>();
        
        // Adding key-value pairs to the HashMap
        hashMap.put(1, "Bala");
        hashMap.put(2, "Hari");
        hashMap.put(3, "nadh");
        
        // Printing the HashMap
        System.out.println("HashMap: " + hashMap);
        
        // Creating a Hashtable
        Map<Integer, String> hashtable = new Hashtable<Integer, String>();
        
        // Adding key-value pairs to the Hashtable
        hashtable.put(1, "Bala");
        hashtable.put(2, "Hari");
        hashtable.put(3, "nadh");
        
        // Printing the Hashtable
        System.out.println("Hashtable: " + hashtable);

	}

}
