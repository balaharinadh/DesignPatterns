/**
 * 
 */
package question12;


/**
 * @author S549411
 *
 */
public class Driver {
	public static final int MAX_VALUE = 100;
	/**
	 * @param args
	 */
	protected void finalize() throws Throwable {
       System.out.println("Finalize Method");
    }
	public static void main(String[] args) throws Throwable {
		Driver d1=new Driver();
		d1.finalize();
		 try {
	            // Code that may throw an exception
	            int num1 = 10;
	            int num2 = 0;
	            int result = num1 / num2; // This line will throw an ArithmeticException
	        } catch (ArithmeticException e) {
	            // Exception handling code
	            System.out.println("An error occurred: " + e.getMessage());
	        } finally {
	            // Code that will always execute
	            System.out.println("Inside finally block");
	        }

	}

}
