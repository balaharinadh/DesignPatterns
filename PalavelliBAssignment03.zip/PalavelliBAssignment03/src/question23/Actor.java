package question23;

public final class Actor {
	private final String name;
    private final int age;
	/**
	 * @param name
	 * @param age
	 */
	public Actor(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
    

}
