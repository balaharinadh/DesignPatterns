package question9;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt"))) {
		    writer.write("Hello, world!");
		    // Code that writes more data to the file
		} catch (IOException e) {
		    // Handle the exception
		}


	}

}
